﻿using Encryption.AES;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MerchantSuccess : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.Params.Count > 0)
        {
            string resdata = (!String.IsNullOrEmpty(Request.Params["respData"])) ? Request.Params["respData"] : string.Empty;
            string key = "hr8er4hf9xW1tx1ah1qH6hU7vr7io7eR";

            MyCryptoClass aes = new MyCryptoClass();
            JavaScriptSerializer ser = new JavaScriptSerializer();

            string dec = aes.decrypt(resdata, key);

            var JSONObj = ser.Deserialize<Dictionary<string, string>>(dec);

     

            lblAgRef.Text = JSONObj["pg_ref_id"];
            lblAmount.Text = JSONObj["txn_amount"];
            lblOrderNumber.Text = JSONObj["txn_id"];
            lblResponseMessage.Text = JSONObj["resp_message"];
            lblTransactionDate.Text = JSONObj["resp_date_time"];
            lblTransactionStatus.Text = JSONObj["trans_status"];
           


        }
    }
}