﻿using System;
using Encryption.AES;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;

public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       

   }

    protected void btns_Click(object sender, EventArgs e)
    {

        string paymentURL = (!String.IsNullOrEmpty(integrationtype.Value)) ? integrationtype.Value : string.Empty;
        string merchantid = (!String.IsNullOrEmpty(merchantId.Value)) ? merchantId.Value : string.Empty;
        string Apikey = (!String.IsNullOrEmpty(apiKey.Value)) ? apiKey.Value : string.Empty;
        string Returnurl = (!String.IsNullOrEmpty(returnURL.Value)) ? returnURL.Value : string.Empty;
        string Type = (!String.IsNullOrEmpty(type.Value)) ? type.Value : string.Empty;
        string Txnid = (!String.IsNullOrEmpty(txnId.Value)) ? txnId.Value : string.Empty;
        string Txntype = (!String.IsNullOrEmpty(txnType.Value)) ? txnType.Value : string.Empty;
        string Amount = (!String.IsNullOrEmpty(amount.Value)) ? amount.Value : string.Empty;
        string DateTime = (!String.IsNullOrEmpty(dateTime.Value)) ? dateTime.Value : string.Empty;
        string ProductId = (!String.IsNullOrEmpty(productId.Value)) ? productId.Value : string.Empty;
        string ChannelId = (!String.IsNullOrEmpty(channelId.Value)) ? channelId.Value : string.Empty;
        string InstrumentId = (!String.IsNullOrEmpty(instrumentId.Value)) ? instrumentId.Value : string.Empty;
        string IsMultiSettlement = (!String.IsNullOrEmpty(isMultiSettlement.Value)) ? isMultiSettlement.Value : string.Empty;
        string CustMobile = (!String.IsNullOrEmpty(custMobile.Value)) ? custMobile.Value : string.Empty;
        string CustMail = (!String.IsNullOrEmpty(custMail.Value)) ? custMail.Value : string.Empty;
        string CardDetails = (!String.IsNullOrEmpty(cardDetails.Value)) ? cardDetails.Value : string.Empty;
        string CardType = (!String.IsNullOrEmpty(cardType.Value)) ? cardType.Value : string.Empty;
        string Udf5 = (!String.IsNullOrEmpty(udf5.Value)) ? udf5.Value : string.Empty;
        string Udf1 = (!String.IsNullOrEmpty(udf1.Value)) ? udf1.Value : string.Empty;
        string Udf2 = (!String.IsNullOrEmpty(udf2.Value)) ? udf2.Value : string.Empty;
        string Udf3 = (!String.IsNullOrEmpty(udf3.Value)) ? udf3.Value : string.Empty;
        string Udf4 = (!String.IsNullOrEmpty(udf4.Value)) ? udf4.Value : string.Empty;



        var data = new Dictionary<String, String>();
        data.Add("merchantId", merchantid);
        data.Add("apiKey", Apikey);
        data.Add("returnURL", Returnurl);
        data.Add("type", Type);
        data.Add("txnId", Txnid);
        data.Add("txnType", Txntype);
        data.Add("amount", Amount);
        data.Add("dateTime", DateTime);
        data.Add("productId", ProductId);
        data.Add("channelId", ChannelId);
        data.Add("instrumentId", InstrumentId);
        data.Add("isMultiSettlement", IsMultiSettlement);
        data.Add("custMobile", CustMobile);
        data.Add("custMail", CustMail);
        data.Add("cardDetails", CardDetails);
        data.Add("cardType", CardType);
        data.Add("udf5", Udf5);
        data.Add("udf1", Udf1);
        data.Add("udf2", Udf2);
        data.Add("udf3", Udf3);
        data.Add("udf4", Udf4);


        string jsonStr = JsonConvert.SerializeObject(data);

        MyCryptoClass aes = new MyCryptoClass();

        string enc = aes.encrypt(jsonStr,Apikey);

        NameValueCollection request = new NameValueCollection();
        request.Add("reqData", enc);
        request.Add("merchantId", merchantid);



        HttpHelper.RedirectAndPOST(this.Page, paymentURL, request);
    }
}